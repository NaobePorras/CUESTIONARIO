﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cuestionario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contador1 = 0;



            if (radioButton1.Checked == true)
            {
                contador += 1;
            }
                if(radioButton2.Checked== true){
                    contador1 += 1;
                }
                if (radioButton3.Checked == true)
                {
                    contador += 1;
                }
                if (radioButton4.Checked == true)
                {
                    contador1 += 1;
                }
                if (radioButton5.Checked == true)
                {
                    contador += 1;
                }
                if (radioButton6.Checked == true)
                {
                    contador1 += 1;
                }
                if (radioButton7.Checked == true)
                {
                    contador += 1;
                }
                if (radioButton8.Checked == true)
                {
                    contador1 += 1;
                }
                if (radioButton9.Checked == true)
                {
                    contador += 1;
                }
                if (radioButton10.Checked == true)
                {
                    contador1 += 1;
                }
                if (radioButton11.Checked == true)
                {
                    contador += 1;
                }
                if (radioButton12.Checked == true)
                {
                    contador1 += 1;
                }
                if (radioButton13.Checked == true)
                {
                    contador += 1;
                }
                if (radioButton14.Checked == true)
                {
                    contador1 += 1;
                }
                if (radioButton15.Checked == true)
                {
                    contador += 1;
                }
                if (radioButton16.Checked == true)
                {
                    contador1 += 1;
                }

            

            if( contador > contador1)
            {
                MessageBox.Show("Extroverido");
            }
            if(contador < contador1)
            {
                MessageBox.Show("Introvertido");
            }
            else
            {
                if (contador1 == contador)
                {
                    MessageBox.Show("iguales");
                }
            }

           
        }



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
